//Name: Luis Solis
//Program Assignment: Lab2
//defines and includes used
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string.h>
#include "String.h"
using std::cout;
using std::endl;
//default
String::String() : c_string()
{
	cout << "String default ctor" << endl;
}
//copy
String::String(const String& other) : c_string(nullptr)
{
	cout << "String copy ctor" << endl;
	if (other.c_string != nullptr)
	{
		c_string = new char[strlen(other.c_string) + 1];
		strcpy(c_string, other.c_string);
	}
}
//dtor
String :: ~String()
{
	cout << "String dtor " << endl;
	delete[] c_string;
	c_string = nullptr;

}
//copy assignment
String& String :: operator = (const String& other)
{
	cout << "String copy =" << endl;
	if (this != &other)
	{
		delete[] c_string;
		if (other.c_string != nullptr)
		{
			c_string = new char[strlen(other.c_string) + 1];
			strcpy(c_string, other.c_string);
		}
		else
		{
			c_string = nullptr;
		}
	}
	return *this;

}
//move ctor
String::String(String&& other) : c_string(other.c_string)
{
	cout << "String move ctor" << endl;
	other.c_string = nullptr;
}
//move assignement
String& String :: operator = (String&& other)
{
	cout << "String move =" << endl;
	if (this != &other)
	{
		delete[] c_string;
		c_string = other.c_string;
		other.c_string = nullptr;
	}
	return *this;
}
//1 arg
String::String(const char* cstring) : c_string(nullptr)
{
	cout << "String 1 arg ctor" << endl;
	if (cstring != nullptr)
	{
		c_string = new char[strlen(cstring) + 1];
		strcpy(c_string, cstring);
	}
}
const char* String::getString()
{
	return c_string;
}