//Name: Luis Solis
//Program Assignment: Lab2
#pragma once

class String {

private: char* c_string;                       //string that will hold out variable
public:
	String();						           //default
	String(const String& other);               //copy
	~String();						           //dtor
	String& operator = (const String& other);  //copy assignment
	String(String&& other);					   //move ctor
	String& operator = (String&& other);       //move assignement
	String(const char* cstring);			   //1 arg
	const char* getString();

};
