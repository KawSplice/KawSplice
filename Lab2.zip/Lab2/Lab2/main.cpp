//Name: Luis Solis
//Program Assignment: Lab2
//defines and includes used
#define _CRTDBG_MAP_ALLOC
#include <iostream>
#include "Deck.h"
#include <ctime>
#include <crtdbg.h>

//using std
using std::endl;
using std::cout;
//functions
void card_function1(const Card&);
void card_function2(Card&);
void card_function3(Card*);
void card_function4(Card);
Card card_function5();
Deck deck_function2();
void deck_function1(Deck);
void DisplayDeck(Deck&);
Deck& deck_function3(Deck& other);
//main

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	srand(time(NULL));
	cout << "1." << endl;
	Card card1;
	Card card2(1, "Spades");
	cout << "2." << endl;
	Card* card3;
	cout << "3." << endl;
	Card card4[3]{};
	cout << "4." << endl;
	Card card5 = card1;
	cout << "5." << endl;
	card3 = new Card;
	cout << "6." << endl;
	card_function1(card2);
	cout << "7." << endl;
	card_function2(card5);
	cout << "8." << endl;
	card_function3(card3);
	cout << "9." << endl;
	card_function4(card2);
	cout << "10." << endl;
	card_function3(card4);
	cout << "11." << endl;
	card_function5();
	cout << "12." << endl;
	Deck deck1;
	cout << "13." << endl;
	delete card3;
	card3 = nullptr;
	cout << "14." << endl;
	deck_function2();
	cout << "15." << endl;
	deck_function1(deck1);
	cout << "16." << endl;
	Deck deck2 = deck_function2();
	cout << "17." << endl;
	deck2 = deck_function2();
	cout << "18." << endl;
	Deck deck3 = deck_function3(deck2);
	cout << "19." << endl;
	deck3 = deck_function3(deck2);
	cout << "20." << endl;
	DisplayDeck(deck1);
	cout << "21." << endl;
	deck1.Shuffle();
	DisplayDeck(deck1);
	cout << "22." << endl;
	deck1.Shuffle();
	DisplayDeck(deck1);
	cout << "end of main" << endl;
	return 0;
}
void card_function1(const Card&)
{

}
void card_function2(Card&)
{

}
void card_function3(Card*)
{

}
void card_function4(Card)
{

}
Card card_function5()
{
	Card local_card;
	return local_card;
}
void deck_function1(Deck)
{

}
Deck deck_function2()
{
	Deck value;
	return value;
}
void DisplayDeck(Deck& other)
{
	Card card_obj;
	
	while (other.AllCardsDealt() != true)
	{
		card_obj = other.DealNextCard();
		cout << card_obj.getRank() << " " << card_obj.getSuit().getString() << endl;
	}
}
Deck& deck_function3(Deck& other)
{
	return other;
}