//Name: Luis Solis
//Program Assignment: Lab2
#pragma once
//defines and includes used
#include "String.h"

class Card {
private:
	int rank;                                    //Ace,2,3,4,5,6,7,8,9,10,jack,queen,king	
	String suit;								 //spades, hearts, clubs, diamonds
public:
	Card();									     //default
	Card(const Card& rank);			             //copy ctor
	~Card();                                     //dtor 
	Card& operator = (const Card& rhs);	         //copy assignment
	Card(Card&& rank);						     //move ctor
	Card& operator = (Card&& rhs);               //move assignment ctor 
	Card(int rank, String suit);			     //2arg ctor
	int getRank();
	String getSuit();
};
