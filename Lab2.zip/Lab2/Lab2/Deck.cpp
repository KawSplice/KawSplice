//Name: Luis Solis
//Program Assignment: Lab2
//defines and includes used
#include <iostream>
#include "Deck.h"
#include "Cards.h"
//using std
using std::cout;
using std::endl;

//default
Deck::Deck() : m_current(0), m_deck{ {1,"Spades"},{2,"Spades"}, {3,"Spades"},{4,"Spades"},{5,"Spades"},{6,"Spades"}, {7,"Spades"},{8,"Spades"},
{9,"Spades"},{10,"Spades"}, {11,"Spades"},{12,"Spades"},{13,"Spades"},{1,"Hearts"},{2,"Hearts"}, {3,"Hearts"},{4,"Hearts"},{5,"Hearts"},{6,"Hearts"}, {7,"Hearts"},{8,"Hearts"}
,{9,"Hearts"},{10,"Hearts"}, {11,"Hearts"},{12,"Hearts"},{13,"Hearts"},{1,"Clubs"},{2,"Clubs"}, {3,"Clubs"},{4,"Clubs"},{5,"Clubs"},{6,"Clubs"}, {7,"Clubs"},{8,"Clubs"}
,{9,"Clubs"},{10,"Clubs"}, {11,"Clubs"},{12,"Clubs"},{13,"Clubs"},{1,"Diamonds"},{2,"Diamonds"}, {3,"Diamonds"},{4,"Diamonds"},{5,"Diamonds"},{6,"Diamonds"}, {7,"Diamonds"},{8,"Diamonds"}
,{9,"Diamonds"},{10,"Diamonds"}, {11,"Diamonds"},{12,"Diamonds"},{13,"Diamonds"} }
{
    cout << "Deck default ctor" << endl;
}
//copy ctor
Deck::Deck(const Deck& other) :m_current(other.m_current), m_deck{
    {other.m_deck[0]},
    {other.m_deck[1]},
    {other.m_deck[2]},
    {other.m_deck[3]},
    {other.m_deck[4]},
    {other.m_deck[5]},
    {other.m_deck[6]},
    {other.m_deck[7]},
    {other.m_deck[8]},
    {other.m_deck[9]},
    {other.m_deck[10]},
    {other.m_deck[11]},
    {other.m_deck[12]},
    {other.m_deck[13]},
    {other.m_deck[14]},
    {other.m_deck[15]},
    {other.m_deck[16]},
    {other.m_deck[17]},
    {other.m_deck[18]},
    {other.m_deck[19]},
    {other.m_deck[20]},
    {other.m_deck[21]},
    {other.m_deck[22]},
    {other.m_deck[23]},
    {other.m_deck[24]},
    {other.m_deck[25]},
    {other.m_deck[26]},
    {other.m_deck[27]},
    {other.m_deck[28]},
    {other.m_deck[29]},
    {other.m_deck[30]},
    {other.m_deck[31]},
    {other.m_deck[32]},
    {other.m_deck[33]},
    {other.m_deck[34]},
    {other.m_deck[35]},
    {other.m_deck[36]},
    {other.m_deck[37]},
    {other.m_deck[38]},
    {other.m_deck[39]},
    {other.m_deck[40]},
    {other.m_deck[41]},
    {other.m_deck[42]},
    {other.m_deck[43]},
    {other.m_deck[44]},
    {other.m_deck[45]},
    {other.m_deck[46]},
    {other.m_deck[47]},
    {other.m_deck[48]},
    {other.m_deck[49]},
    {other.m_deck[50]},
    {other.m_deck[51]} }
{
    cout << "Deck copy ctor" << endl;
}
//dtor
Deck :: ~Deck()
{
    cout << "Deck dtor" << endl;
}
//copy assignment
Deck& Deck :: operator= (const Deck& rhs)
{
    cout << "Deck copy =" << endl;
    if (this != &rhs)
    {
        for (int i = 0; i < 52; i++)
        {
            m_deck[i] = rhs.m_deck[i];
        }
        m_current = rhs.m_current;
    }
    return *this;
}
//move
Deck::Deck(Deck&& other) :m_current(other.m_current), m_deck{
    {std::move(other.m_deck[0])},
    {std::move(other.m_deck[1])},
    {std::move(other.m_deck[2])},
    {std::move(other.m_deck[3])},
    {std::move(other.m_deck[4])},
    {std::move(other.m_deck[5])},
    {std::move(other.m_deck[6])},
    {std::move(other.m_deck[7])},
    {std::move(other.m_deck[8])},
    {std::move(other.m_deck[9])},
    {std::move(other.m_deck[10])},
    {std::move(other.m_deck[11])},
    {std::move(other.m_deck[12])},
    {std::move(other.m_deck[13])},
    {std::move(other.m_deck[14])},
    {std::move(other.m_deck[15])},
    {std::move(other.m_deck[16])},
    {std::move(other.m_deck[17])},
    {std::move(other.m_deck[18])},
    {std::move(other.m_deck[19])},
    {std::move(other.m_deck[20])},
    {std::move(other.m_deck[21])},
    {std::move(other.m_deck[22])},
    {std::move(other.m_deck[23])},
    {std::move(other.m_deck[24])},
    {std::move(other.m_deck[25])},
    {std::move(other.m_deck[26])},
    {std::move(other.m_deck[27])},
    {std::move(other.m_deck[28])},
    {std::move(other.m_deck[29])},
    {std::move(other.m_deck[30])},
    {std::move(other.m_deck[31])},
    {std::move(other.m_deck[32])},
    {std::move(other.m_deck[33])},
    {std::move(other.m_deck[34])},
    {std::move(other.m_deck[35])},
    {std::move(other.m_deck[36])},
    {std::move(other.m_deck[37])},
    {std::move(other.m_deck[38])},
    {std::move(other.m_deck[39])},
    {std::move(other.m_deck[40])},
    {std::move(other.m_deck[41])},
    {std::move(other.m_deck[42])},
    {std::move(other.m_deck[43])},
    {std::move(other.m_deck[44])},
    {std::move(other.m_deck[45])},
    {std::move(other.m_deck[46])},
    {std::move(other.m_deck[47])},
    {std::move(other.m_deck[48])},
    {std::move(other.m_deck[49])},
    {std::move(other.m_deck[50])},
    {std::move(other.m_deck[51])} }
{
    cout << " Deck move ctor" << endl;
}
//move assignment
Deck& Deck :: operator = (Deck&& rhs)
{
    cout << " Deck move =" << endl;
    if (this != &rhs)
    {
        for (int i = 0; i < 52; i++)
        {
            m_deck[i] = std::move(rhs.m_deck[i]);
        }
        m_current = rhs.m_current;
    }
    return *this;
}

Card Deck:: DealNextCard()
{
    return m_deck[m_current++];
}
bool Deck :: AllCardsDealt()
{
    if (m_current != 52)
    {
        return false;
    }
    else
    {
        return true;
    }
}
void Deck:: Shuffle()
{
    m_current = 0;
    Card temp;
    for (int i = 0; i < 52; i++)
    {
        int number = rand() % 52;
        temp = m_deck[i];
        m_deck[i] = m_deck[number];
        m_deck[number] = temp;
    }
}

